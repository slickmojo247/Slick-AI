# Knowledge base logic
