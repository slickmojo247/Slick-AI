# long_term.py
