# ai_manager.py
