# Mediation logic
