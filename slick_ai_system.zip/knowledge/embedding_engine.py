# embedding_engine.py
