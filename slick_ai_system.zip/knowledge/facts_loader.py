# facts_loader.py
