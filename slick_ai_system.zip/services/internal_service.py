# internal_service.py
