# external_service.py
