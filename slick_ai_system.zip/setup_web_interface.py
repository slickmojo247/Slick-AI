# FastAPI setup logic
