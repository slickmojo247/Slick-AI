# Slick AI System
Run with `slick start`
